<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bg.jpeg");
background-repeat:no-repeat;
background-size: 1400px 800px;
margin:0;
}
div.head {
  font-family: Purisa, sans-serif;
  font-size:60px;
  color:white;
  }
 div.container {
 border:1px solid black;
    width:1000px; 
    margin:0;
   position: absolute;
  left:12%;
    background-color:white;
  }
img {vertical-align: middle;
width:20%;
height:20%;}
.topnav {
  overflow: hidden;
  background-color: #F00000;
   position: auto;
    top: 35%;
    width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
}


 

</style>

</head>
<body>

<div class="lol">

<a href="login.php"><button style="float:right;">LOGIN</button></a>
 <a href="creg.php"><button style="float:right;">REGISTER</button></a> 
<div class="head">Surprise...!</div>

 
<div class="topnav">
  <a class="" href="reg1.html">HOME</a>
  <a href="#about">ABOUT</a>
  <a href="display.php">PRODUCTS</a>
 <a href="cartdisplay.php"><i class="fa fa-shopping-cart" style="font-size:24px;color:white"></i></a>
  
</div>
<div class="container">

<p><span class="error">LOGIN</span></p>
<form name="myform" method="post" action="login1.php">

  E-mail: <input type="text" name="email">
  <span class="error">* </span>
 </br> 
  </br>
 
   Password: <input type="password" name="password">
  <span class="error">* </span>
 </br> 
  </br>
 
  <input type="submit" name="submit" value="Submit">  
  </br>
</form>
  </br>  </br>  </br>
</div>
</body>
</html>.























