<?php
session_start();
include 'connect.php';

    if(isset($_GET['action']) && $_GET['action']=="add"){ 
          
        $id=intval($_GET['id']); 
          
       


$query = "delete from cart where pro_id='$id'";
$result = mysqli_query($con,$query) or die('error querying database'.mysqli_error($con));
if($result==TRUE)
{
 $msg="added to cart succesfully";
  echo "<script>
 
        window.location.href='cartdisplay.php';
        </script>";
        }
        }
        ?>
