<?php
session_start(); // Starting Session
include 'connect.php';
$msg="";
$category=$_POST['category'];
$price=$_POST['price'];
$name=$_SESSION['username'];
if(isset($_POST['upload'])){
  $target="uploads/".basename($_FILES['userfile']['name']);

  $pdf=$_FILES['userfile']['name'];
  $error=$_FILES['userfile']['error'];
  


 $sql="INSERT INTO items(userfile,category,price,username) VALUES('$pdf','$category','$price','$name')";
 mysqli_query($con,$sql) or die('sorry'.mysqli_error($con));

 if(move_uploaded_file($_FILES['userfile']['tmp_name'],$target)){

  $msg="file uploaded succesfully";
  echo "<script>
  alert('successfully uploaded');
        window.location.href='upload.php';
        </script>";
}
else{
$msg="Failed to upload a file";
   echo "<script>
  alert('error uploading image');
        window.location.href='upload.php';
        </script>";
}
}

?>
