<?php
session_start();
include 'connect.php';
$query="select * from voting where section=$_SESSION[sec]";
$result=mysqli_query($db,$query) or die("error querying database");
echo '<form id="myform">';
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
{
echo '<input type="radio" name="candidate" id="name2" value="'.$row['can_name'].'" >'.$row['can_name'].'</input><br />';
echo '<a href='/uploads'>view manifesto</a>';
}
echo '</form>';
?>
