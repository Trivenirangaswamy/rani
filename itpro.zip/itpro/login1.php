<?php
session_start(); // Starting Session
$username=$_POST['email'];
$password=$_POST['password'];
$_SESSION['username']=$username;
if (isset($_POST['submit'])) {
if (empty($_POST['email']) || empty($_POST['password'])) {
header("location: loginerror.php");
}
else
{

$connection = mysqli_connect("localhost", "root", "divya","itpro") or die("cannot connect to database");
// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);

// SQL query to fetch information of registerd users and finds user match.
$query ="select *from login where password='$password' AND username='$username'"; 
$result=mysqli_query($connection,$query)or die("error querying database".mysqli_error($connection));
$row  = mysqli_fetch_array($result);
$user_type=$row['user_type'];



	if($row>0) 
 	{
	if($user_type=='1')
	{
		header('location:summary.php');
	} 
	else
	{
		header('location:upload.php');
	}
	}
	else
	{
	header('location:loginerror.php');
	}
mysqli_close($conn);
}
}
?>
