<?php
$name=$_POST['name'];
$username=$_POST['email'];
$mobile=$_POST['num'];
$password=$_POST['password'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysqli_connect("localhost", "root", "divya","itpro") or die("cannot connect to database");


// SQL query to fetch information of registerd users and finds user match.
$query ="insert into customer_details(name,email,contact)values('$name','$username','$mobile')" or die("error querying database".mysqli_error($connection));
$query1 ="insert into login(username,password,user_type)values('$username','$password',1)" or die("error querying database");
$result=mysqli_query($connection,$query);
$result1=mysqli_query($connection,$query1);
 // Closing Connection
if($result1==TRUE)
{
header("location:reg1.html");
}
else
{
$error=mysqli_error($connection);
echo $error;
}

?>
