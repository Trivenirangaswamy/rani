<?php
session_start(); // Starting Session
include 'connect.php';
$msg="";
$category=$_POST['category'];
$price=$_POST['price'];
$name=$_SESSION['username'];
if(isset($_POST['upload'])){
  $target="uploads/".basename($_FILES['userfile']['name']);

  $pdf=$_FILES['userfile']['name'];
  $error=$_FILES['userfile']['error'];
  


 $sql="INSERT INTO items(userfile,category,price,username) VALUES('$pdf','$category','$price','$name')";
 mysqli_query($con,$sql) or die('sorry'.mysqli_error($con));
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["userfile"]["name"]);
$extension = end($temp);
if ((($_FILES["userfile"]["type"] == "image/gif")
|| ($_FILES["userfile"]["type"] == "image/jpeg")
|| ($_FILES["userfile"]["type"] == "image/jpg")
|| ($_FILES["userfile"]["type"] == "image/pjpeg")
|| ($_FILES["userfile"]["type"] == "image/x-png")
|| ($_FILES["userfile"]["type"] == "image/png"))
&& ($_FILES["userfile"]["size"] < 20000000000000000000000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["userfile"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["userfile"]["error"] . "<br>";
    }
  else
    {
    echo "Upload: " . $_FILES["userfile"]["name"] . "<br>";
    echo "Type: " . $_FILES["userfile"]["type"] . "<br>";
    echo "Size: " . ($_FILES["userfile"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["userfile"]["tmp_name"] . "<br>";

    if (file_exists("uploads/" . $_FILES["userfile"]["name"]))
      {
      echo $_FILES["userfile"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["userfile"]["tmp_name"],
      "uploads/" . $_FILES["userfile"]["name"]);
      echo "Stored in: " . "uploads/" . $_FILES["userfile"]["name"]."<br>";

$image=$_FILES["userfile"]["name"]; /* Displaying Image*/
      $img="uploads/".$image;
    echo'<img src="'.$img.'">';

      }
    }
  }
else
  {
  echo "Invalid file";
  }
  }
?>
